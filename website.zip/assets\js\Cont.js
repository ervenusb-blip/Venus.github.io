body {
    font - family: Arial, sans - serif;
    background - color: #f2f2f2;
    display: flex;
    justify - content: center;
    align - items: center;
    height: 100 vh;
    margin: 0;
}

.contact - box {
    width: 360 px;
    padding: 20 px;
    background - color: #fff;
    border: 2 px solid #007BFF;

                                                    border-radius: 8px;

                                                    box-sizing: border-box;

                                                }

                                                

                                                .contact-box h2 {

                                                    text-align: center;

                                                    margin-top: 0;

                                                    margin-bottom: 15px;

                                                }

                                                

                                                .contact-box label {

                                                    display: block;

                                                    margin-bottom: 6px;

                                                    font-weight: bold;

                                                    color: # 333;
}

.contact - box input[type = "text"],
    .contact - box input[type = "email"],
    .contact - box textarea {
        width: 100 % ;
        padding: 10 px;
        margin - bottom: 15 px;
        border: 1 px solid# ccc;
        border - radius: 4 px;
        box - sizing: border - box;
        font - size: 14 px;
    }

.contact - box textarea {
    resize: vertical;
    height: 100 px;
}

.contact - box button {
    width: 100 % ;
    padding: 12 px;
    border: none;
    background - color: #007BFF;

                                                    color: # fff;
    border - radius: 5 px;
    font - size: 16 px;
    cursor: pointer;
}

.contact - box button: hover {
        background - color: #0056b3;

                                                }

                                                

                                                .contact-box p.status {

                                                    text-align: center;

                                                    margin-top: 10px;

                                                    font-size: 14px;

                                                    color: green;

                                                }